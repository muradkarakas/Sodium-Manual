var input_elements =
[
    [ "Text Item", "input_text.html", "input_text" ],
    [ "Radio Item", "input_radio.html", "input_radio" ],
    [ "Select Item", "input_select.html", "input_select" ],
    [ "Checkbox Item", "input_checkbox.html", "input_checkbox" ],
    [ "Button Item", "input_button.html", "input_button" ],
    [ "Image Item", "input_image.html", "input_image" ],
    [ "Textarea Item", "input_textarea.html", "input_textarea" ],
    [ "Magic Buttons", "input_magic_buttons.html", null ]
];