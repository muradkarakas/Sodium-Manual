var input_select =
[
    [ "name Property", "input_name.html", null ],
    [ "column-name Property", "input_column_name.html", null ],
    [ "data-type Property", "input_data_type.html", null ],
    [ "default-value Property", "input_default_value.html", null ],
    [ "insert-allowed Property", "input_insert_allowed.html", null ],
    [ "update-allowed Property", "input_update_allowed.html", null ],
    [ "data-list-name Property", "input_datalist_name.html", null ],
    [ "lookup-input-block-name Property", "input_lookup_input_block_name.html", null ],
    [ "lookup-input-name Property", "input_lookup_input_name.html", null ]
];