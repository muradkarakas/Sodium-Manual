var input_checkbox =
[
    [ "name Property", "input_name.html", null ],
    [ "column-name Property", "input_column_name.html", null ],
    [ "data-type Property", "input_data_type.html", null ],
    [ "type Property", "input_type.html", null ],
    [ "insert-allowed Property", "input_insert_allowed.html", null ],
    [ "update-allowed Property", "input_update_allowed.html", null ],
    [ "unchecked-value Property", "input_unchecked_value.html", null ],
    [ "checked-value Property", "input_checked_value.html", null ]
];