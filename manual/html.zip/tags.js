var tags =
[
    [ "Data Block", "data_block.html", "data_block" ],
    [ "Control Block", "control_block.html", "control_block" ],
    [ "Data List", "data_list.html", "data_list" ],
    [ "Tree Element", "tree.html", "tree" ],
    [ "Table TAG", "table.html", null ],
    [ "Inputs", "input_elements.html", "input_elements" ]
];