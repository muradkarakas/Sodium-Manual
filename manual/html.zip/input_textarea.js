var input_textarea =
[
    [ "name Property", "input_name.html", null ],
    [ "data-type Property", "input_data_type.html", null ],
    [ "column-name Property", "input_column_name.html", null ],
    [ "Rows Property", "input_textarea_rows.html", null ]
];