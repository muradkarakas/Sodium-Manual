var built_in_functions =
[
    [ "HT/SQL Built-in Functions", "htsql_built_in_functions.html", "htsql_built_in_functions" ],
    [ "Built-in String Functions & Operands", "string_functions.html", "string_functions" ],
    [ "Date/time Functions", "date_time_functions.html", null ],
    [ "File IO functions", "file_io_functions.html", null ]
];