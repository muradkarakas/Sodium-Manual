var input_radio =
[
    [ "name Property", "input_name.html", null ],
    [ "column-name Property", "input_column_name.html", null ],
    [ "type Property", "input_type.html", null ],
    [ "data-type Property", "input_data_type.html", null ],
    [ "insert-allowed Property", "input_insert_allowed.html", null ],
    [ "update-allowed Property", "input_update_allowed.html", null ],
    [ "checked-value Property", "input_checked_value.html", null ],
    [ "default-value Property", "input_default_value.html", null ]
];