var input_text =
[
    [ "name Property", "input_name.html", null ],
    [ "type Property", "input_type.html", null ],
    [ "data-type Property", "input_data_type.html", null ],
    [ "master-item-name Property", "input_master_item_name.html", null ],
    [ "sequence-name Property", "input_sequence_name.html", null ],
    [ "value Property", "input_value.html", null ],
    [ "maxlength Property", "input_maxlength.html", null ],
    [ "column-name Property", "input_column_name.html", null ],
    [ "insert-allowed Property", "input_insert_allowed.html", null ],
    [ "update-allowed Property", "input_update_allowed.html", null ],
    [ "format-mask Property", "input_format_mask.html", null ]
];