var language_reference =
[
    [ "Built-in Functions", "built_in_functions.html", "built_in_functions" ],
    [ "Built-in Triggers", "built_in_triggers.html", "built_in_triggers" ],
    [ "TAGs", "tags.html", "tags" ],
    [ "Connection Types", "connections.html", "connections" ],
    [ "Native SQL support", "native_sql_support.html", null ],
    [ "Lexical Elements", "lexical_elements.html", "lexical_elements" ],
    [ "Program Structure", "program_structure.html", "program_structure" ],
    [ "Predefined Variables", "predefined_variables.html", "predefined_variables" ],
    [ "CSS Themes", "css_themes.html", null ],
    [ "Scopes", "scope.html", null ],
    [ "Debugging", "debugging.html", null ]
];