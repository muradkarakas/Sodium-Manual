var variables =
[
    [ "Variable Type: int", "variable_types_int.html", null ],
    [ "Variable Type: char", "variable_types_char.html", null ],
    [ "Variable Type: bool", "variable_types_bool.html", null ],
    [ "Local variables", "variable_type_local.html", null ],
    [ "Page variables", "variable_type_page.html", null ],
    [ "Session variables", "variable_type_session.html", null ],
    [ "Predefined Variables", "predefined_variables.html", "predefined_variables" ]
];