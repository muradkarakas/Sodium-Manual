var input_button =
[
    [ "name Property", "input_name.html", null ],
    [ "type Property", "input_type.html", null ],
    [ "value Property", "input_value.html", null ]
];