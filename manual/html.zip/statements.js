var statements =
[
    [ "The \"if\" Statement", "if_statement.html", null ],
    [ "The while Statement", "while_statement.html", null ],
    [ "The do Statement", "do_statement.html", null ],
    [ "Blocks", "blocks.html", null ],
    [ "The break Statement", "break_statement.html", null ],
    [ "The return Statement", "return_statement.html", null ]
];