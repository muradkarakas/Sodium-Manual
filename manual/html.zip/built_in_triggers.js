var built_in_triggers =
[
    [ "\"item_modified\" trigger", "item_modified.html", null ],
    [ "\"connection_not_found\" trigger", "connection_not_found.html", null ],
    [ "\"page.access\" trigger", "page_access.html", null ],
    [ "\"page_load\" trigger", "page_load.html", null ],
    [ "\"post_query\" trigger", "post_query.html", null ],
    [ "\"row_selected\" trigger", "row_selected.html", null ],
    [ "\"button_item_clicked\" trigger", "trigger_button_item_clicked.html", null ],
    [ "\"pre_insert\" Trigger", "trigger_pre_insert.html", null ],
    [ "\"pre_delete\" Trigger", "trigger_pre_delete.html", null ],
    [ "\"pre_update\" Trigger", "trigger_pre_update.html", null ],
    [ "\"post_insert\" Trigger", "trigger_post_insert.html", null ],
    [ "\"post_delete\" Trigger", "trigger_post_delete.html", null ],
    [ "\"post_update\" Trigger", "trigger_post_update.html", null ],
    [ "\"tree_node_expanded\" Trigger", "trigger_tree_node_expanded.html", null ],
    [ "\"tree_node_selected\" Trigger", "trigger_tree_node_selected.html", null ],
    [ "\"user_session_end\" trigger", "trigger_user_session_end.html", null ]
];