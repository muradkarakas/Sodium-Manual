var NAVTREE =
[
  [ "HT/SQL", "index.html", [
    [ "About Me", "about_me.html", null ],
    [ "Contributers", "contributers.html", null ],
    [ "Developer Tools", "devtools.html", "devtools" ],
    [ "Download Page", "download_page.html", null ],
    [ "Frequently Asked Questions", "faq.html", null ],
    [ "Getting Started", "getting_started.html", "getting_started" ],
    [ "How to", "howto.html", "howto" ],
    [ "Installation and Configuration", "installation_and__configuration.html", "installation_and__configuration" ],
    [ "Introduction", "introduction.html", null ],
    [ "Language Reference", "language_reference.html", "language_reference" ]
  ] ]
];

var NAVTREEINDEX =
[
"about_me.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';