var input_image =
[
    [ "name Property", "input_name.html", null ],
    [ "type Property", "input_type.html", null ],
    [ "column-name Property", "input_column_name.html", null ]
];