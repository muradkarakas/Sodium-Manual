var searchData=
[
  ['name_20property',['name Property',['../input_name.html',1,'input_textarea']]],
  ['native_20sql_20support',['Native SQL support',['../native_sql_support.html',1,'language_reference']]]
];
