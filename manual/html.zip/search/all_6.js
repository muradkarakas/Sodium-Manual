var searchData=
[
  ['get_5fdatabase_5fname',['get_database_name',['../function_get_database_name.html',1,'htsql_built_in_functions']]],
  ['get_5fdatabase_5ftype',['get_database_type',['../function_get_database_type.html',1,'htsql_built_in_functions']]],
  ['getting_20started',['Getting Started',['../getting_started.html',1,'']]]
];
