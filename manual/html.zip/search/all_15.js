var searchData=
[
  ['where_2dclause_20property',['where-clause property',['../datablock_where_clause.html',1,'data_block']]],
  ['white_20space',['White Space',['../white_space.html',1,'lexical_elements']]]
];
