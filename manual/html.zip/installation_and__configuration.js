var installation_and__configuration =
[
    [ "Installation on Windows systems", "installation_on_windows_systems.html", null ],
    [ "Uninstallation from Windows systems", "uninstallation_from_windows.html", null ]
];