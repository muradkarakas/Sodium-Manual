var data_list =
[
    [ "id property", "datalist_id.html", null ],
    [ "connection-name property", "datalist_connection_name.html", null ]
];