var string_functions =
[
    [ "strlen", "strlen.html", null ],
    [ "Concatanation Operator", "string_concatenation.html", null ],
    [ "instr", "instr.html", null ],
    [ "replace", "replace.html", null ],
    [ "substr", "substr.html", null ],
    [ "The \"sizeof\" Operator", "sizeof_operator.html", null ],
    [ "Like & Not Like Operators", "like_operator.html", null ]
];