var predefined_variables =
[
    [ ":Session.authenticated", "predefined_session_authenticated.html", null ],
    [ ":Session.user", "predefined_session_user.html", null ],
    [ ":Session.Id", "predefined_password.html", null ],
    [ ":Session.user", "predefined_session_id.html", null ],
    [ ":Row.Id", "predefined_row_id.html", null ]
];