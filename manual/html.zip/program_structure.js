var program_structure =
[
    [ "Form File", "frmx_file.html", null ],
    [ "Code Behind File", "code_behind_file.html", null ],
    [ "Controller File", "controller_file.html", null ]
];