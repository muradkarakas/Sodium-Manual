var data_block =
[
    [ "data-block-name property", "datablock_data_block_name.html", null ],
    [ "data-source-name property", "datablock_data_source_name.html", null ],
    [ "data-schema-name property", "datablock_data_schema_name.html", null ],
    [ "connection-name property", "datablock_connection_name.html", null ],
    [ "where-clause property", "datablock_where_clause.html", null ],
    [ "order-by-clause property", "datablock_order_by_clause.html", null ],
    [ "master-data-block-name property", "datablock_master_data_block_name.html", null ],
    [ "join-condition  property", "datablock_join_condition.html", null ],
    [ "record-count  property", "datablock_record_count.html", null ],
    [ "insert-allowed  property", "datablock_insert_allowed.html", null ],
    [ "update-allowed  property", "datablock_update_allowed.html", null ],
    [ "delete-allowed  property", "datablock_delete_allowed.html", null ],
    [ "show-hide-mode  property", "datablock_show_hide_mode.html", null ],
    [ "auto-generated-columns property", "datablock_auto_generated_columns.html", null ],
    [ "Data Block: Form View Mode", "data_block_form_view.html", null ],
    [ "Data Block: Grid View Mode", "data_block_grid_view.html", null ],
    [ "Data Block: Mix View Mode", "data_block_mix_view.html", null ]
];