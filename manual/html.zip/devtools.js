var devtools =
[
    [ "Developer Tools: HTML5 Schema Definition File for HT/SQL", "devtools_vs_xsd_file.html", null ]
];